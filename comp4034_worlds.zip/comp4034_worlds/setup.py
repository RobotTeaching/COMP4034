import os
from glob import glob
from setuptools import find_packages, setup


package_name = 'comp4034_worlds'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', ['launch/turtlebot3_P3_house.launch.py']),
        ('share/' + package_name + '/launch', ['launch/turtlebot3_P4_A.launch.py']),
        (os.path.join('share', package_name, 'worlds'),
        glob('worlds/*')),
    ] + [
    (os.path.join('share', package_name, root),
        [os.path.join(root, filename)])
    for root, _, files in os.walk('models')
    for filename in files
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='team-user',
    maintainer_email='team-user@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    extras_require={
        'test': [
            'pytest',
        ],
    },
    entry_points={
        'console_scripts': [
            'image_node = comp4034_worlds.image_node:main'
        ],
    },
)
