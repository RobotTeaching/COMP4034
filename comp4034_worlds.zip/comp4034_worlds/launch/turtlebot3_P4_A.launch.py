#!/usr/bin/env python3

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import IncludeLaunchDescription, TimerAction, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration


def generate_launch_description():

    # Locate the required packages
    pkg_worlds = get_package_share_directory('comp4034_worlds')
    launch_file_dir = os.path.join(
        get_package_share_directory('turtlebot3_gazebo'),
        'launch'
    )
    pkg_gazebo_ros = get_package_share_directory('gazebo_ros')

    # Custom world belonging to comp4034_worlds
    world = os.path.join(
        pkg_worlds,
        'worlds',
        'turtlebot3_P4_A.world'
    )

    print(f"\n\nCUSTOM WORLD PATH: {world}\n")
    print(f"WORLD EXISTS: {os.path.exists(world)}\n")

    # Custom models belonging to comp4034_worlds
    models_dir = os.path.join(pkg_worlds, 'models')

    # Simulation configuration
    use_sim_time = LaunchConfiguration('use_sim_time', default='true')
    x_pose = LaunchConfiguration('x_pose', default='-3.0')
    y_pose = LaunchConfiguration('y_pose', default='-2.0')
    yaw = LaunchConfiguration('yaw', default='3.14')


    # Make custom models available to Gazebo Classic
    existing_model_path = os.environ.get('GAZEBO_MODEL_PATH', '')
    model_path = (
        models_dir + os.pathsep + existing_model_path
        if existing_model_path
        else models_dir
    )

    set_gazebo_model_path = SetEnvironmentVariable(
        name='GAZEBO_MODEL_PATH',
        value=model_path
    )

    # Start Gazebo server with the custom world
    gzserver_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzserver.launch.py')
        ),
        launch_arguments={'world': world}.items()
    )

    # Start Gazebo client
    gzclient_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(pkg_gazebo_ros, 'launch', 'gzclient.launch.py')
        )
    )

    # Publish the robot's state
    robot_state_publisher_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                launch_file_dir,
                'robot_state_publisher.launch.py'
            )
        ),
        launch_arguments={
            'use_sim_time': use_sim_time
        }.items()
    )

    # Spawn the TurtleBot3
    spawn_turtlebot_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(
            os.path.join(
                launch_file_dir,
                'spawn_turtlebot3.launch.py'
            )
        ),
        launch_arguments={
            'x_pose': x_pose,
            'y_pose': y_pose,
            'yaw' : yaw
        }.items()
    )

    # Allow Gazebo time to start before spawning the robot
    delayed_spawn_turtlebot = TimerAction(
        period=5.0,
        actions=[spawn_turtlebot_cmd]
    )

    return LaunchDescription([
        set_gazebo_model_path,
        gzserver_cmd,
        gzclient_cmd,
        robot_state_publisher_cmd,
        delayed_spawn_turtlebot,
    ])
